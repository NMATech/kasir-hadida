<div id="cardMenuBarang" class="pl-3 <?= $title == 'Barang' || $title == 'Kategori Barang' ? 'flex' : 'hidden' ?>">
    <ul class="flex flex-col gap-3">
        <a href="<?= base_url('/barang') ?>">
            <li class="flex items-center gap-2 <?= $title == 'Barang' ? 'bg-sky-500 text-white' : '' ?> hover:bg-sky-500 hover:text-white cursor-pointer rounded-lg ease-in-out p-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
                </svg>
                <p class="text-sm">Data Barang</p>
            </li>
        </a>
        <a href="<?= base_url('/kategori') ?>">
            <li class="flex items-center gap-2 <?= $title == 'Kategori Barang' ? 'bg-sky-500 text-white' : '' ?> hover:bg-sky-500 hover:text-white cursor-pointer rounded-lg ease-in-out p-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z" />
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 6h.008v.008H6V6Z" />
                </svg>
                <p class="text-sm">Kategori Barang</p>
            </li>
        </a>
    </ul>
</div>