<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir Hadida</title>

    <link rel="stylesheet" href="<?= base_url('assets/css/output.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/DataTables/datatables.min.css') ?>">
</head>

<body class="bg-[#efefef] flex font-mono">
    <?= $this->include('components/sidebar'); ?>

    <main id="container-content" class="w-[85%] h-svh">
        <?= $this->include('components/navbar'); ?>

        <!-- modal -->
        <?= $this->include('components/modal/modalDelete'); ?>
        <?= $this->include('components/modal/modalSuccess'); ?>

        <div class="p-5">
            <?= $this->renderSection('content'); ?>
        </div>
    </main>

    <script src="<?= base_url('assets/DataTables/datatables.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/sweetalert.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/index.js') ?>"></script>
    <script src="<?= base_url('assets/js/barang.js') ?>"></script>
    <script src="<?= base_url('assets/js/modal.js') ?>"></script>
    <script src="<?= base_url('assets/js/kategori.js') ?>"></script>
    <script src="<?= base_url('assets/js/users.js') ?>"></script>
</body>

</html>