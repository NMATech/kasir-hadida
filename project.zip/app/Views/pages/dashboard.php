<?= $this->extend('layouts/layout'); ?>

<?= $this->section('content'); ?>
<div class="flex flex-col">
    <h3 class="text-3xl font-bold"><?= $title; ?></h3>
    <p class="text-sm">15 November 2025</p>
</div>
<?= $this->endSection(); ?>